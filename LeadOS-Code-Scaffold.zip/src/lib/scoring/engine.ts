// ═══════════════════════════════════════════════════════════════════
// LeadOS Scoring Engine
// Pure function module for lead scoring across 6 dimensions
// ═══════════════════════════════════════════════════════════════════

export interface ScoringWeights {
  intent: number;      // Default: 0.25
  fit: number;         // Default: 0.20
  accessibility: number; // Default: 0.15
  opportunity: number; // Default: 0.20
  competition: number; // Default: 0.10
  complexity: number;  // Default: 0.10
}

export interface ScoringInput {
  // Intent signals
  demandSignalType: 'rfp' | 'forum_post' | 'job_listing' | 'directory' | 'social_post' | 'website_signal' | 'manual';
  discoveredDaysAgo: number;
  hasExplicitBudget: boolean;
  hasUrgencySignal: boolean;
  triggerKeywordStrength: 'weak' | 'moderate' | 'strong' | 'explicit';

  // Fit signals
  industryMatchesICP: boolean;
  geographyMatchesICP: boolean;
  companySizeMatchesICP: boolean;
  serviceOverlapCount: number;   // How many requested services match agency offerings
  totalServicesNeeded: number;

  // Accessibility signals
  hasPublicEmail: boolean;
  hasPublicPhone: boolean;
  hasLinkedInProfile: boolean;
  hasTeamPage: boolean;
  hasContactForm: boolean;
  emailConfidence: number;       // 0.0 to 1.0

  // Opportunity signals
  companySize: 'micro' | 'small' | 'medium' | 'large' | 'enterprise';
  hasBudgetSignals: boolean;
  multiServicePotential: boolean;
  growthSignals: boolean;

  // Competition signals
  sourceExclusivity: 'high' | 'medium' | 'low';   // How many others likely found this
  nicheSpecificity: 'generic' | 'moderate' | 'niche';
  existingAgencyDetected: boolean;

  // Complexity signals
  scopeBreadth: 'narrow' | 'moderate' | 'broad';
  requiresSeniorDM: boolean;
  hasProcurementProcess: boolean;
  technicalComplexity: 'low' | 'medium' | 'high';
}

export interface DimensionScore {
  score: number;       // 0-100
  reasons: string[];
}

export interface ScoringResult {
  finalScore: number;
  intent: DimensionScore;
  fit: DimensionScore;
  accessibility: DimensionScore;
  opportunity: DimensionScore;
  competition: DimensionScore;
  complexity: DimensionScore;
}

// ═══════════════════════════════════════════
// DEFAULT WEIGHTS
// ═══════════════════════════════════════════

export const DEFAULT_WEIGHTS: ScoringWeights = {
  intent: 0.25,
  fit: 0.20,
  accessibility: 0.15,
  opportunity: 0.20,
  competition: 0.10,
  complexity: 0.10,
};

// ═══════════════════════════════════════════
// DIMENSION SCORERS
// ═══════════════════════════════════════════

function scoreIntent(input: ScoringInput): DimensionScore {
  let score = 0;
  const reasons: string[] = [];

  // Demand signal type (0-35 points)
  const signalScores: Record<string, number> = {
    rfp: 35, forum_post: 25, social_post: 22, job_listing: 18, directory: 15, website_signal: 12, manual: 10
  };
  const signalScore = signalScores[input.demandSignalType] || 10;
  score += signalScore;
  reasons.push(`Demand signal type: ${input.demandSignalType} (+${signalScore})`);

  // Recency (0-25 points)
  let recencyScore = 0;
  if (input.discoveredDaysAgo <= 3) { recencyScore = 25; reasons.push('Discovered within 3 days (+25)'); }
  else if (input.discoveredDaysAgo <= 7) { recencyScore = 20; reasons.push('Discovered within 7 days (+20)'); }
  else if (input.discoveredDaysAgo <= 14) { recencyScore = 15; reasons.push('Discovered within 14 days (+15)'); }
  else if (input.discoveredDaysAgo <= 30) { recencyScore = 10; reasons.push('Discovered within 30 days (+10)'); }
  else { recencyScore = 5; reasons.push('Discovered over 30 days ago (+5)'); }
  score += recencyScore;

  // Budget signal (0-20 points)
  if (input.hasExplicitBudget) { score += 20; reasons.push('Explicit budget mentioned (+20)'); }

  // Urgency (0-10 points)
  if (input.hasUrgencySignal) { score += 10; reasons.push('Urgency signals detected (+10)'); }

  // Keyword strength (0-10 points)
  const kwScores: Record<string, number> = { explicit: 10, strong: 8, moderate: 5, weak: 2 };
  const kwScore = kwScores[input.triggerKeywordStrength] || 2;
  score += kwScore;
  reasons.push(`Keyword strength: ${input.triggerKeywordStrength} (+${kwScore})`);

  return { score: Math.min(score, 100), reasons };
}

function scoreFit(input: ScoringInput): DimensionScore {
  let score = 0;
  const reasons: string[] = [];

  if (input.industryMatchesICP) { score += 30; reasons.push('Industry matches ICP (+30)'); }
  if (input.geographyMatchesICP) { score += 25; reasons.push('Geography matches ICP (+25)'); }
  if (input.companySizeMatchesICP) { score += 20; reasons.push('Company size matches ICP (+20)'); }

  // Service overlap (0-25 points)
  const overlapRatio = input.totalServicesNeeded > 0 ? input.serviceOverlapCount / input.totalServicesNeeded : 0;
  const overlapScore = Math.round(overlapRatio * 25);
  score += overlapScore;
  reasons.push(`Service overlap: ${input.serviceOverlapCount}/${input.totalServicesNeeded} (+${overlapScore})`);

  return { score: Math.min(score, 100), reasons };
}

function scoreAccessibility(input: ScoringInput): DimensionScore {
  let score = 0;
  const reasons: string[] = [];

  if (input.hasPublicEmail) { score += 30; reasons.push('Public email available (+30)'); }
  if (input.hasPublicPhone) { score += 15; reasons.push('Public phone listed (+15)'); }
  if (input.hasLinkedInProfile) { score += 20; reasons.push('LinkedIn profile identified (+20)'); }
  if (input.hasTeamPage) { score += 15; reasons.push('Team page exists (+15)'); }
  if (input.hasContactForm) { score += 10; reasons.push('Contact form accessible (+10)'); }

  // Email confidence bonus (0-10 points)
  if (input.emailConfidence > 0) {
    const confScore = Math.round(input.emailConfidence * 10);
    score += confScore;
    reasons.push(`Email confidence: ${Math.round(input.emailConfidence * 100)}% (+${confScore})`);
  }

  return { score: Math.min(score, 100), reasons };
}

function scoreOpportunity(input: ScoringInput): DimensionScore {
  let score = 0;
  const reasons: string[] = [];

  // Company size (0-30 points)
  const sizeScores: Record<string, number> = { enterprise: 30, large: 25, medium: 20, small: 12, micro: 5 };
  const sizeScore = sizeScores[input.companySize] || 10;
  score += sizeScore;
  reasons.push(`Company size: ${input.companySize} (+${sizeScore})`);

  if (input.hasBudgetSignals) { score += 25; reasons.push('Budget maturity signals (+25)'); }
  if (input.multiServicePotential) { score += 25; reasons.push('Multi-service potential (+25)'); }
  if (input.growthSignals) { score += 20; reasons.push('Growth signals detected (+20)'); }

  return { score: Math.min(score, 100), reasons };
}

// NOTE: Competition and Complexity are INVERSE scored
// Lower competition = HIGHER score (better for us)
// Lower complexity = HIGHER score (easier to close)

function scoreCompetition(input: ScoringInput): DimensionScore {
  let score = 100; // Start high, deduct for competition
  const reasons: string[] = [];

  // Source exclusivity
  const exclusivityDeductions: Record<string, number> = { high: 0, medium: -20, low: -40 };
  const exDeduction = exclusivityDeductions[input.sourceExclusivity] || -20;
  score += exDeduction;
  if (exDeduction < 0) reasons.push(`Source exclusivity: ${input.sourceExclusivity} (${exDeduction})`);
  else reasons.push('High source exclusivity (no deduction)');

  // Niche specificity
  const nicheBonus: Record<string, number> = { niche: 0, moderate: -15, generic: -30 };
  const nBonus = nicheBonus[input.nicheSpecificity] || -15;
  score += nBonus;
  if (nBonus < 0) reasons.push(`Niche specificity: ${input.nicheSpecificity} (${nBonus})`);

  // Existing agency
  if (input.existingAgencyDetected) { score -= 20; reasons.push('Existing agency detected (-20)'); }

  return { score: Math.max(0, Math.min(score, 100)), reasons };
}

function scoreComplexity(input: ScoringInput): DimensionScore {
  let score = 100; // Start high, deduct for complexity
  const reasons: string[] = [];

  // Scope breadth
  const scopeDeductions: Record<string, number> = { narrow: 0, moderate: -15, broad: -30 };
  const scopeD = scopeDeductions[input.scopeBreadth] || -15;
  score += scopeD;
  reasons.push(`Scope: ${input.scopeBreadth} (${scopeD === 0 ? 'no deduction' : scopeD})`);

  if (input.requiresSeniorDM) { score -= 15; reasons.push('Requires senior decision-maker (-15)'); }
  if (input.hasProcurementProcess) { score -= 20; reasons.push('Formal procurement process (-20)'); }

  const techDeductions: Record<string, number> = { low: 0, medium: -10, high: -25 };
  const techD = techDeductions[input.technicalComplexity] || -10;
  score += techD;
  if (techD < 0) reasons.push(`Technical complexity: ${input.technicalComplexity} (${techD})`);

  return { score: Math.max(0, Math.min(score, 100)), reasons };
}

// ═══════════════════════════════════════════
// MAIN SCORING FUNCTION
// ═══════════════════════════════════════════

export function scoreLead(
  input: ScoringInput,
  weights: ScoringWeights = DEFAULT_WEIGHTS
): ScoringResult {
  const intent = scoreIntent(input);
  const fit = scoreFit(input);
  const accessibility = scoreAccessibility(input);
  const opportunity = scoreOpportunity(input);
  const competition = scoreCompetition(input);
  const complexity = scoreComplexity(input);

  const finalScore = Math.round(
    (intent.score * weights.intent) +
    (fit.score * weights.fit) +
    (accessibility.score * weights.accessibility) +
    (opportunity.score * weights.opportunity) +
    (competition.score * weights.competition) +
    (complexity.score * weights.complexity)
  );

  return {
    finalScore: Math.min(finalScore, 100),
    intent,
    fit,
    accessibility,
    opportunity,
    competition,
    complexity,
  };
}

// ═══════════════════════════════════════════
// BATCH SCORING
// ═══════════════════════════════════════════

export function scoreLeads(
  inputs: Array<{ id: string; input: ScoringInput }>,
  weights: ScoringWeights = DEFAULT_WEIGHTS
): Array<{ id: string; result: ScoringResult }> {
  return inputs
    .map(({ id, input }) => ({ id, result: scoreLead(input, weights) }))
    .sort((a, b) => b.result.finalScore - a.result.finalScore);
}

// ═══════════════════════════════════════════
// WEIGHT VALIDATION
// ═══════════════════════════════════════════

export function validateWeights(weights: ScoringWeights): { valid: boolean; error?: string } {
  const sum = Object.values(weights).reduce((a, b) => a + b, 0);
  if (Math.abs(sum - 1.0) > 0.01) {
    return { valid: false, error: `Weights must sum to 1.0, got ${sum.toFixed(2)}` };
  }
  for (const [key, value] of Object.entries(weights)) {
    if (value < 0 || value > 1) {
      return { valid: false, error: `Weight '${key}' must be between 0 and 1, got ${value}` };
    }
  }
  return { valid: true };
}

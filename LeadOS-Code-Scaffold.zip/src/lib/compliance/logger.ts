// ═══════════════════════════════════════════════════════════════════
// LeadOS Compliance Logging
// Immutable audit trail for all data operations
// ═══════════════════════════════════════════════════════════════════

import { createServerSupabaseClient } from '@/lib/supabase/client';

export type ComplianceAction =
  | 'crawl_started' | 'crawl_completed' | 'crawl_failed'
  | 'lead_created' | 'lead_enriched'
  | 'contact_added'
  | 'outreach_sent'
  | 'source_enabled' | 'source_disabled' | 'source_blocked'
  | 'robots_validated'
  | 'manual_override'
  | 'data_exported'
  | 'admin_action';

export interface ComplianceLogEntry {
  workspaceId: string;
  action: ComplianceAction;
  entityType: string;
  entityId?: string;
  actorId?: string;
  actorType?: 'user' | 'system' | 'automation';
  details?: Record<string, unknown>;
  sourceConnectorId?: string;
}

// ═══════════════════════════════════════════
// LOG WRITER (append-only)
// ═══════════════════════════════════════════

export async function logComplianceEvent(entry: ComplianceLogEntry): Promise<void> {
  const supabase = createServerSupabaseClient();

  const { error } = await supabase.from('compliance_logs').insert({
    workspace_id: entry.workspaceId,
    action: entry.action,
    entity_type: entry.entityType,
    entity_id: entry.entityId,
    actor_id: entry.actorId,
    actor_type: entry.actorType || 'system',
    details: entry.details || {},
    source_connector_id: entry.sourceConnectorId,
  });

  if (error) {
    // Compliance logging should never silently fail
    // In production, this should alert monitoring
    console.error('[COMPLIANCE] Failed to write log:', error);
    throw new Error(`Compliance logging failed: ${error.message}`);
  }
}

// ═══════════════════════════════════════════
// CONVENIENCE LOGGERS
// ═══════════════════════════════════════════

export async function logCrawlStarted(
  workspaceId: string, sourceId: string, jobId: string
): Promise<void> {
  await logComplianceEvent({
    workspaceId,
    action: 'crawl_started',
    entityType: 'search_job',
    entityId: jobId,
    actorType: 'system',
    sourceConnectorId: sourceId,
    details: { startedAt: new Date().toISOString() },
  });
}

export async function logLeadCreated(
  workspaceId: string, leadId: string, sourceId: string | null, userId?: string
): Promise<void> {
  await logComplianceEvent({
    workspaceId,
    action: 'lead_created',
    entityType: 'lead',
    entityId: leadId,
    actorId: userId,
    actorType: userId ? 'user' : 'system',
    sourceConnectorId: sourceId || undefined,
    details: { createdAt: new Date().toISOString() },
  });
}

export async function logOutreachSent(
  workspaceId: string, draftId: string, leadId: string, userId: string, channel: string
): Promise<void> {
  await logComplianceEvent({
    workspaceId,
    action: 'outreach_sent',
    entityType: 'outreach_draft',
    entityId: draftId,
    actorId: userId,
    actorType: 'user',
    details: { leadId, channel, sentAt: new Date().toISOString() },
  });
}

export async function logManualOverride(
  workspaceId: string, entityType: string, entityId: string,
  fieldName: string, oldValue: unknown, newValue: unknown,
  userId: string, reason?: string
): Promise<void> {
  await logComplianceEvent({
    workspaceId,
    action: 'manual_override',
    entityType,
    entityId,
    actorId: userId,
    actorType: 'user',
    details: { fieldName, oldValue, newValue, reason },
  });
}

// ═══════════════════════════════════════════
// LOG READER (for compliance dashboard)
// ═══════════════════════════════════════════

export async function getComplianceLogs(
  workspaceId: string,
  options: {
    limit?: number;
    offset?: number;
    actions?: ComplianceAction[];
    entityType?: string;
    startDate?: string;
    endDate?: string;
  } = {}
) {
  const supabase = createServerSupabaseClient();
  const { limit = 50, offset = 0, actions, entityType, startDate, endDate } = options;

  let query = supabase
    .from('compliance_logs')
    .select('*', { count: 'exact' })
    .eq('workspace_id', workspaceId)
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1);

  if (actions?.length) query = query.in('action', actions);
  if (entityType) query = query.eq('entity_type', entityType);
  if (startDate) query = query.gte('created_at', startDate);
  if (endDate) query = query.lte('created_at', endDate);

  const { data, error, count } = await query;
  if (error) throw error;

  return { logs: data, total: count || 0 };
}

// ═══════════════════════════════════════════════════════════════════
// LeadOS Outreach Template Engine
// Generates personalized outreach drafts from lead + audit data
// ═══════════════════════════════════════════════════════════════════

import type { Lead, LeadContact, AuditReport, OutreachDraft } from '@/types';

export type TemplateType = 'cold_email' | 'followup' | 'audit_offer' | 'proposal_intro' | 'reminder' | 'linkedin_message' | 'intro_note';

export interface TemplateContext {
  lead: Lead;
  contact: LeadContact | null;
  audit: AuditReport | null;
  senderName: string;
  senderTitle: string;
  agencyName: string;
  agencyWebsite: string;
}

export interface GeneratedDraft {
  subject: string | null;
  body: string;
  channel: 'email' | 'linkedin' | 'other';
  templateType: TemplateType;
  personalizationData: Record<string, string>;
  evidenceUsed: Record<string, unknown>;
}

// ═══════════════════════════════════════════
// PERSONALIZATION VARIABLES
// ═══════════════════════════════════════════

function buildVariables(ctx: TemplateContext): Record<string, string> {
  const auditHighlights = ctx.audit?.modules
    ?.filter(m => m.score < 50)
    ?.map(m => `${m.moduleName}: ${m.score}/100`)
    ?.slice(0, 3)
    ?.join(', ') || 'digital presence opportunities identified';

  const quickWins = ctx.audit?.quickWins
    ?.slice(0, 3)
    ?.map(w => w.title)
    ?.join(', ') || 'several quick improvements available';

  return {
    '{{company_name}}': ctx.lead.companyName,
    '{{website}}': ctx.lead.website || 'your website',
    '{{contact_name}}': ctx.contact?.fullName || '[Name]',
    '{{contact_first_name}}': ctx.contact?.fullName?.split(' ')[0] || '[First Name]',
    '{{contact_title}}': ctx.contact?.designation || '[Title]',
    '{{industry}}': ctx.lead.industry || 'your industry',
    '{{service_needed}}': ctx.lead.likelyServiceNeeded?.join(', ') || 'digital marketing',
    '{{trigger_keyword}}': ctx.lead.triggerKeyword || 'growth',
    '{{need_summary}}': ctx.lead.needSummary || 'digital growth opportunities',
    '{{city}}': ctx.lead.city || '',
    '{{country}}': ctx.lead.country || '',
    '{{audit_highlights}}': auditHighlights,
    '{{quick_wins}}': quickWins,
    '{{sender_name}}': ctx.senderName,
    '{{sender_title}}': ctx.senderTitle,
    '{{agency_name}}': ctx.agencyName,
    '{{agency_website}}': ctx.agencyWebsite,
  };
}

function interpolate(template: string, vars: Record<string, string>): string {
  let result = template;
  for (const [key, value] of Object.entries(vars)) {
    result = result.replaceAll(key, value);
  }
  return result;
}

// ═══════════════════════════════════════════
// TEMPLATES
// ═══════════════════════════════════════════

const TEMPLATES: Record<TemplateType, { subject?: string; body: string; channel: 'email' | 'linkedin' | 'other' }> = {
  cold_email: {
    channel: 'email',
    subject: 'Quick observation about {{website}} — thought it might help',
    body: `Hi {{contact_first_name}},

I came across {{company_name}} while researching {{industry}} companies investing in {{service_needed}}.

{{need_summary}} — I noticed a few areas where some focused work could drive meaningful results.

Would it be helpful if I shared a quick audit of what we found? No commitment needed — I just thought the insights might be useful for your team.

Happy to set up a 15-minute call if that is easier.

Best,
{{sender_name}}
{{sender_title}}, {{agency_name}}`,
  },

  audit_offer: {
    channel: 'email',
    subject: 'Free {{service_needed}} audit for {{company_name}} — 3 quick wins inside',
    body: `Hi {{contact_first_name}},

We recently ran a quick digital audit on {{website}} and found some interesting opportunities:

- {{audit_highlights}}
- Quick wins available: {{quick_wins}}

We put this together because we genuinely think there is low-hanging fruit your team could action right away.

Would you like me to send over the full findings? It is completely free and there are no strings attached — just thought it might be useful.

Best,
{{sender_name}}
{{sender_title}}, {{agency_name}}`,
  },

  followup: {
    channel: 'email',
    subject: 'Re: Quick observation about {{website}}',
    body: `Hi {{contact_first_name}},

Following up on my note from last week about the opportunities we spotted on {{website}}.

I wanted to share one specific finding: {{audit_highlights}}. This is something that can typically be improved within the first 2-3 weeks with focused effort.

Would a quick 10-minute call work to walk through what we found?

Best,
{{sender_name}}`,
  },

  proposal_intro: {
    channel: 'email',
    subject: '{{company_name}} x {{agency_name}} — Growth proposal',
    body: `Hi {{contact_first_name}},

Thank you for the conversation about {{company_name}}'s {{service_needed}} goals.

Based on our audit findings and your team's priorities, we have put together a focused proposal covering:

1. Current state assessment ({{audit_highlights}})
2. Recommended strategy and execution plan
3. Expected outcomes and timeline
4. Investment and team structure

I have attached the proposal for your review. Happy to walk through it whenever works for your schedule.

Best,
{{sender_name}}
{{sender_title}}, {{agency_name}}`,
  },

  linkedin_message: {
    channel: 'linkedin',
    body: `Hi {{contact_first_name}}, I noticed {{company_name}} is growing in the {{industry}} space — congratulations on the momentum.

I work with similar companies on {{service_needed}} and noticed a few opportunities on {{website}} that might be worth exploring.

Would you be open to a quick chat?`,
  },

  reminder: {
    channel: 'email',
    subject: 'Quick check-in — {{company_name}} audit findings',
    body: `Hi {{contact_first_name}},

Just a quick note to check if you had a chance to review the audit findings I shared for {{website}}.

Happy to answer any questions or jump on a brief call if that is easier. No rush at all.

Best,
{{sender_name}}`,
  },

  intro_note: {
    channel: 'email',
    subject: 'Hello from {{agency_name}} — {{service_needed}} for {{industry}}',
    body: `Hi {{contact_first_name}},

I am {{sender_name}} from {{agency_name}}. We help {{industry}} companies grow through structured {{service_needed}} systems.

I came across {{company_name}} and thought there might be a fit for a conversation about your digital growth goals.

Would you be open to a brief introductory call this week?

Best,
{{sender_name}}
{{sender_title}}, {{agency_name}}
{{agency_website}}`,
  },
};

// ═══════════════════════════════════════════
// DRAFT GENERATOR
// ═══════════════════════════════════════════

export function generateDraft(
  templateType: TemplateType,
  ctx: TemplateContext
): GeneratedDraft {
  const template = TEMPLATES[templateType];
  if (!template) throw new Error(`Unknown template type: ${templateType}`);

  const vars = buildVariables(ctx);
  const body = interpolate(template.body, vars);
  const subject = template.subject ? interpolate(template.subject, vars) : null;

  return {
    subject,
    body,
    channel: template.channel,
    templateType,
    personalizationData: vars,
    evidenceUsed: {
      leadId: ctx.lead.id,
      auditId: ctx.audit?.id,
      contactId: ctx.contact?.id,
      triggerKeyword: ctx.lead.triggerKeyword,
      demandSignalType: ctx.lead.demandSignalType,
      sourceUrl: ctx.lead.sourceUrl,
    },
  };
}

// ═══════════════════════════════════════════
// BATCH GENERATION
// ═══════════════════════════════════════════

export function generateDraftsForLead(
  ctx: TemplateContext,
  templateTypes: TemplateType[] = ['cold_email']
): GeneratedDraft[] {
  return templateTypes.map(type => generateDraft(type, ctx));
}

// ═══════════════════════════════════════════
// DUPLICATE OUTREACH CHECK
// ═══════════════════════════════════════════

export interface DuplicateCheckResult {
  isDuplicate: boolean;
  lastContactedAt: string | null;
  daysSinceLastContact: number | null;
  channel: string | null;
  warning: string | null;
}

export function checkDuplicateOutreach(
  existingDrafts: Pick<OutreachDraft, 'sentAt' | 'channel' | 'status'>[],
  duplicateWindowDays: number = 30
): DuplicateCheckResult {
  const sentDrafts = existingDrafts
    .filter(d => d.status === 'sent' && d.sentAt)
    .sort((a, b) => new Date(b.sentAt!).getTime() - new Date(a.sentAt!).getTime());

  if (sentDrafts.length === 0) {
    return { isDuplicate: false, lastContactedAt: null, daysSinceLastContact: null, channel: null, warning: null };
  }

  const lastSent = sentDrafts[0];
  const daysSince = Math.floor((Date.now() - new Date(lastSent.sentAt!).getTime()) / (1000 * 60 * 60 * 24));

  if (daysSince < duplicateWindowDays) {
    return {
      isDuplicate: true,
      lastContactedAt: lastSent.sentAt!,
      daysSinceLastContact: daysSince,
      channel: lastSent.channel,
      warning: `Contact was reached via ${lastSent.channel} ${daysSince} days ago. Duplicate window is ${duplicateWindowDays} days.`,
    };
  }

  return {
    isDuplicate: false,
    lastContactedAt: lastSent.sentAt!,
    daysSinceLastContact: daysSince,
    channel: lastSent.channel,
    warning: null,
  };
}

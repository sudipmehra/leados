// ═══════════════════════════════════════════════════════════════════
// LeadOS Source Connector Interface
// Every data source implements this interface
// ═══════════════════════════════════════════════════════════════════

export type SourceType = 'directory' | 'forum' | 'job_board' | 'social' | 'website' | 'api' | 'manual';
export type CrawlMethod = 'api' | 'rss' | 'html_parse' | 'manual' | 'webhook';

export interface ConnectorConfig {
  baseUrl?: string;
  apiKey?: string;
  selectors?: Record<string, string>;
  headers?: Record<string, string>;
  auth?: { type: 'none' | 'api_key' | 'oauth' | 'basic'; config: Record<string, string> };
  customParams?: Record<string, unknown>;
}

export interface RateLimit {
  requestsPerMinute: number;
  requestsPerHour: number;
  requestsPerDay: number;
  concurrentRequests: number;
  delayBetweenRequestsMs: number;
}

export interface ComplianceResult {
  isCompliant: boolean;
  robotsTxtAllowed: boolean;
  tosAllowed: boolean;
  rateWithinLimits: boolean;
  issues: string[];
  checkedAt: Date;
}

export interface RawLead {
  companyName?: string;
  website?: string;
  sourceUrl: string;
  rawData: Record<string, unknown>;
  discoveredAt: Date;
}

export interface NormalizedLead {
  companyName: string;
  website?: string;
  sourceUrl: string;
  country?: string;
  region?: string;
  city?: string;
  industry?: string;
  likelyServiceNeeded: string[];
  triggerKeyword?: string;
  needSummary?: string;
  demandSignalType: string;
  discoveredAt: Date;
  contactName?: string;
  contactTitle?: string;
  contactEmail?: string;
  contactPhone?: string;
  sourceEvidence: Record<string, unknown>;
}

export interface ICPQuery {
  servicesNeeded: string[];
  industries: string[];
  geographies: { countries: string[]; regions: string[]; cities: string[] };
  companySizes: string[];
  keywords: string[];
  intentPhrases: string[];
  exclusions: { keywords: string[]; domains: string[] };
}

// ═══════════════════════════════════════════
// CONNECTOR INTERFACE
// ═══════════════════════════════════════════

export interface ISourceConnector {
  // Identity
  readonly name: string;
  readonly type: SourceType;
  readonly crawlMethod: CrawlMethod;
  readonly trustScore: number;

  // Configuration
  configure(config: ConnectorConfig): void;

  // Compliance
  validateCompliance(): Promise<ComplianceResult>;
  checkRobotsTxt(url: string): Promise<boolean>;
  getRateLimit(): RateLimit;

  // Discovery
  fetchLeads(query: ICPQuery): Promise<RawLead[]>;
  normalizeLeads(raw: RawLead[]): NormalizedLead[];

  // Health
  healthCheck(): Promise<{ healthy: boolean; message: string }>;
}

// ═══════════════════════════════════════════
// BASE CONNECTOR CLASS
// ═══════════════════════════════════════════

export abstract class BaseConnector implements ISourceConnector {
  abstract readonly name: string;
  abstract readonly type: SourceType;
  abstract readonly crawlMethod: CrawlMethod;
  abstract readonly trustScore: number;

  protected config: ConnectorConfig = {};
  protected lastRequestTime = 0;
  protected requestCount = 0;

  configure(config: ConnectorConfig): void {
    this.config = { ...this.config, ...config };
  }

  getRateLimit(): RateLimit {
    return {
      requestsPerMinute: 10,
      requestsPerHour: 100,
      requestsPerDay: 500,
      concurrentRequests: 1,
      delayBetweenRequestsMs: 6000, // 10 req/min
    };
  }

  async checkRobotsTxt(_url: string): Promise<boolean> {
    // Default implementation - should be overridden
    // In production, fetch and parse robots.txt
    return true;
  }

  async validateCompliance(): Promise<ComplianceResult> {
    const issues: string[] = [];
    let robotsTxtAllowed = true;
    let tosAllowed = true;

    if (this.config.baseUrl) {
      robotsTxtAllowed = await this.checkRobotsTxt(this.config.baseUrl);
      if (!robotsTxtAllowed) {
        issues.push(`robots.txt disallows crawling of ${this.config.baseUrl}`);
      }
    }

    return {
      isCompliant: issues.length === 0,
      robotsTxtAllowed,
      tosAllowed,
      rateWithinLimits: true,
      issues,
      checkedAt: new Date(),
    };
  }

  protected async respectRateLimit(): Promise<void> {
    const now = Date.now();
    const limit = this.getRateLimit();
    const elapsed = now - this.lastRequestTime;
    if (elapsed < limit.delayBetweenRequestsMs) {
      await new Promise(resolve =>
        setTimeout(resolve, limit.delayBetweenRequestsMs - elapsed)
      );
    }
    this.lastRequestTime = Date.now();
    this.requestCount++;
  }

  abstract fetchLeads(query: ICPQuery): Promise<RawLead[]>;
  abstract normalizeLeads(raw: RawLead[]): NormalizedLead[];
  abstract healthCheck(): Promise<{ healthy: boolean; message: string }>;
}

// ═══════════════════════════════════════════
// CONNECTOR REGISTRY
// ═══════════════════════════════════════════

class ConnectorRegistry {
  private connectors: Map<string, ISourceConnector> = new Map();

  register(id: string, connector: ISourceConnector): void {
    this.connectors.set(id, connector);
  }

  get(id: string): ISourceConnector | undefined {
    return this.connectors.get(id);
  }

  getAll(): Map<string, ISourceConnector> {
    return new Map(this.connectors);
  }

  getByType(type: SourceType): ISourceConnector[] {
    return Array.from(this.connectors.values()).filter(c => c.type === type);
  }

  async healthCheckAll(): Promise<Map<string, { healthy: boolean; message: string }>> {
    const results = new Map();
    for (const [id, connector] of this.connectors) {
      try {
        results.set(id, await connector.healthCheck());
      } catch (error) {
        results.set(id, { healthy: false, message: String(error) });
      }
    }
    return results;
  }
}

export const connectorRegistry = new ConnectorRegistry();

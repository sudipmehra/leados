// ═══════════════════════════════════════════════════════════════════
// LeadOS Core TypeScript Types
// ═══════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════
// DATABASE ENTITY TYPES
// ═══════════════════════════════════════════

export interface Workspace {
  id: string;
  name: string;
  slug: string;
  plan: 'free' | 'pro' | 'enterprise';
  settings: WorkspaceSettings;
  ownerId: string;
  createdAt: string;
  updatedAt: string;
}

export interface WorkspaceSettings {
  scoringWeights: {
    intent: number;
    fit: number;
    accessibility: number;
    opportunity: number;
    competition: number;
    complexity: number;
  };
  maxSendsPerDay: number;
  duplicateWindowDays: number;
  defaultGeographies: string[];
  defaultIndustries: string[];
}

export interface UserProfile {
  id: string;
  email: string;
  fullName: string;
  role: 'admin' | 'manager' | 'member';
  workspaceId: string | null;
  avatarUrl: string | null;
  preferences: Record<string, unknown>;
  createdAt: string;
  updatedAt: string;
}

export interface ICP {
  id: string;
  workspaceId: string;
  name: string;
  description: string | null;
  servicesNeeded: string[];
  industries: string[];
  geographies: { countries: string[]; regions: string[]; cities: string[] };
  companySizes: string[];
  businessTypes: string[];
  keywords: string[];
  intentPhrases: string[];
  exclusions: { keywords: string[]; domains: string[]; industries: string[] };
  isActive: boolean;
  createdBy: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface SourceConnector {
  id: string;
  workspaceId: string;
  name: string;
  sourceType: 'directory' | 'forum' | 'job_board' | 'social' | 'website' | 'api' | 'manual';
  crawlMethod: 'api' | 'rss' | 'html_parse' | 'manual' | 'webhook';
  connectorConfig: Record<string, unknown>;
  allowedFields: string[];
  rateLimitRpm: number;
  trustScore: number;
  complianceStatus: 'approved' | 'review' | 'blocked';
  robotsTxtUrl: string | null;
  lastCrawlAt: string | null;
  totalLeadsFound: number;
  isEnabled: boolean;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Lead {
  id: string;
  workspaceId: string;
  companyName: string;
  website: string | null;
  logoUrl: string | null;
  sourceConnectorId: string | null;
  sourceUrl: string | null;
  sourceEvidence: Record<string, unknown>;
  country: string | null;
  region: string | null;
  city: string | null;
  industry: string | null;
  companySize: string | null;
  businessType: string | null;
  likelyServiceNeeded: string[];
  triggerKeyword: string | null;
  needSummary: string | null;
  demandSignalType: 'rfp' | 'forum_post' | 'job_listing' | 'directory' | 'social_post' | 'website_signal' | 'manual';
  discoveredAt: string;
  leadScore: number;
  intentScore: number;
  fitScore: number;
  accessibilityScore: number;
  opportunityScore: number;
  competitionScore: number;
  complexityScore: number;
  scoreExplanation: Record<string, { score: number; reasons: string[] }>;
  scoredAt: string | null;
  enrichmentStatus: 'none' | 'partial' | 'complete' | 'failed';
  auditStatus: 'none' | 'in_progress' | 'complete';
  outreachStatus: 'none' | 'drafted' | 'sent' | 'replied' | 'converted';
  proposalStatus: 'none' | 'preparing' | 'sent' | 'won' | 'lost';
  confidenceLevel: 'low' | 'medium' | 'high' | 'verified';
  ownerId: string | null;
  tags: string[];
  notes: string | null;
  canonicalId: string | null;
  isArchived: boolean;
  searchJobId: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface LeadContact {
  id: string;
  leadId: string;
  workspaceId: string;
  fullName: string | null;
  designation: string | null;
  department: string | null;
  email: string | null;
  emailConfidence: number;
  emailVerifiedAt: string | null;
  phone: string | null;
  phoneType: string | null;
  linkedinUrl: string | null;
  twitterUrl: string | null;
  source: 'public_website' | 'enrichment_api' | 'manual' | 'social_profile';
  sourceUrl: string | null;
  isDecisionMaker: boolean;
  isPrimary: boolean;
  enrichmentProvider: string | null;
  enrichmentData: Record<string, unknown> | null;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface AuditReport {
  id: string;
  leadId: string;
  workspaceId: string;
  templateId: string;
  status: 'draft' | 'in_review' | 'finalized';
  modules: AuditModule[];
  summary: string | null;
  quickWins: AuditRecommendation[];
  thirtyDayPlan: AuditPlanItem[];
  internalNotes: string | null;
  clientSnapshot: Record<string, unknown> | null;
  pdfUrl: string | null;
  pdfGeneratedAt: string | null;
  createdBy: string | null;
  reviewedBy: string | null;
  finalizedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface AuditModule {
  moduleId: string;
  moduleName: string;
  automationLevel: 'automated' | 'semi_automated' | 'ai_assisted' | 'manual';
  score: number;
  maxScore: number;
  status: 'pending' | 'running' | 'complete' | 'skipped';
  automatedData: Record<string, unknown>;
  aiAnalysis: string | null;
  manualNotes: string | null;
  findings: AuditFinding[];
  recommendations: string[];
  evidenceUrls: string[];
}

export interface AuditFinding {
  id: string;
  severity: 'info' | 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  category: string;
}

export interface AuditRecommendation {
  id: string;
  priority: number;
  title: string;
  description: string;
  effort: 'low' | 'medium' | 'high';
  impact: 'low' | 'medium' | 'high';
}

export interface AuditPlanItem {
  week: number;
  title: string;
  actions: string[];
}

export interface OutreachDraft {
  id: string;
  leadId: string;
  contactId: string | null;
  workspaceId: string;
  channel: 'email' | 'linkedin' | 'other';
  templateType: 'cold_email' | 'followup' | 'audit_offer' | 'proposal_intro' | 'reminder' | 'linkedin_message' | 'intro_note';
  subject: string | null;
  body: string;
  personalizationData: Record<string, string>;
  evidenceUsed: Record<string, unknown>;
  status: 'draft' | 'pending_review' | 'approved' | 'sent' | 'failed';
  approvedBy: string | null;
  approvedAt: string | null;
  sentAt: string | null;
  sendProvider: string | null;
  sendResult: Record<string, unknown> | null;
  messageId: string | null;
  version: number;
  parentDraftId: string | null;
  createdBy: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface SearchJob {
  id: string;
  workspaceId: string;
  icpId: string;
  status: 'queued' | 'running' | 'completed' | 'failed' | 'cancelled';
  sourcesUsed: string[];
  queryParams: Record<string, unknown>;
  totalDiscovered: number;
  totalQualified: number;
  totalDuplicates: number;
  totalRejected: number;
  startedAt: string | null;
  completedAt: string | null;
  errorLog: Array<{ source: string; error: string; timestamp: string }>;
  createdBy: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface ComplianceLog {
  id: string;
  workspaceId: string;
  action: string;
  entityType: string;
  entityId: string | null;
  actorId: string | null;
  actorType: 'user' | 'system' | 'automation';
  details: Record<string, unknown>;
  sourceConnectorId: string | null;
  createdAt: string;
}

// ═══════════════════════════════════════════
// API / UI TYPES
// ═══════════════════════════════════════════

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

export interface LeadFilters {
  search?: string;
  statuses?: string[];
  industries?: string[];
  countries?: string[];
  services?: string[];
  signals?: string[];
  scoreMin?: number;
  scoreMax?: number;
  enrichmentStatuses?: string[];
  auditStatuses?: string[];
  outreachStatuses?: string[];
  tags?: string[];
  ownerId?: string;
  discoveredAfter?: string;
  discoveredBefore?: string;
}

export interface LeadSortConfig {
  field: 'lead_score' | 'discovered_at' | 'company_name' | 'industry' | 'country';
  direction: 'asc' | 'desc';
}

export interface DashboardStats {
  totalLeads: number;
  qualifiedLeads: number;
  auditsCompleted: number;
  outreachSent: number;
  repliesReceived: number;
  conversions: number;
  weekOverWeek: {
    leads: number;
    qualified: number;
    audits: number;
    outreach: number;
  };
}

// Service categories offered by the agency
export const SERVICE_CATEGORIES = [
  'Digital Marketing',
  'Social Media Marketing',
  'SEO',
  'PPC / Paid Ads',
  'Performance Marketing',
  'Content Marketing',
  'Website Revamp',
  'Branding',
  'Creative Services',
  'Lead Generation',
  'Email Marketing',
  'Marketing Automation',
  'CRM Integration',
  'Video Marketing',
  'Influencer Marketing',
] as const;

export const INDUSTRIES = [
  'SaaS', 'E-commerce', 'D2C / FMCG', 'Financial Services', 'Healthcare',
  'Education', 'Real Estate', 'Legal Services', 'Manufacturing', 'Logistics',
  'Travel & Hospitality', 'Food & Beverage', 'Fashion & Apparel', 'Automotive',
  'Technology', 'Media & Entertainment', 'Non-Profit', 'Government',
  'Home & Living', 'Health & Fitness', 'Data Analytics',
] as const;

export const COMPANY_SIZES = [
  'micro',      // 1-10 employees
  'small',      // 11-50 employees
  'medium',     // 51-200 employees
  'large',      // 201-1000 employees
  'enterprise', // 1000+ employees
] as const;
